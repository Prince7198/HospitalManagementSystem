CREATE DATABASE IF NOT EXISTS healthlink_hospital;

-- Use the database
USE healthlink_hospital;

-- Create the users table for User Model
CREATE TABLE IF NOT EXISTS users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(255) NOT NULL,
    password VARCHAR(255) NOT NULL,
    role VARCHAR(50) NOT NULL
);

INSERT INTO users (username, password, role) VALUES
    ('testdoctor', 'doctor123', 'doctor'),
    ('testreceptionist', 'receptionist123', 'receptionist'),
    ('testadmin', 'admin123', 'admin');

-- Create the ehr_records table for EHR Model
CREATE TABLE IF NOT EXISTS ehr_records (
    ehr_id INT AUTO_INCREMENT PRIMARY KEY,
    patient_id INT,
    diagnosis TEXT,
    treatment TEXT,
    medical_history TEXT,
    allergies TEXT
);

-- Create the patients table for Patient Model
CREATE TABLE IF NOT EXISTS patients (
    patient_id INT AUTO_INCREMENT PRIMARY KEY,
    first_name VARCHAR(255) NOT NULL,
    last_name VARCHAR(255) NOT NULL,
    date_of_birth DATE,
    contact_number VARCHAR(15),
    email VARCHAR(255),
    address VARCHAR(255),
    ehr_id INT,
    FOREIGN KEY (ehr_id) REFERENCES ehr_records(ehr_id)
);

-- Create the appointments table for Appointment Model
CREATE TABLE IF NOT EXISTS appointments (
    appointment_id INT AUTO_INCREMENT PRIMARY KEY,
    patient_id INT,
    doctor_id INT,
    appointment_date DATETIME,
    status VARCHAR(50),
    FOREIGN KEY (patient_id) REFERENCES patients(patient_id)
    -- Add foreign key reference for doctor_id if applicable
);

-- Create the invoices table for Billing and Invoice Model
CREATE TABLE IF NOT EXISTS invoices (
    invoice_id INT AUTO_INCREMENT PRIMARY KEY,
    patient_id INT,
    invoice_date DATE,
    amount DECIMAL(10, 2),
    status VARCHAR(50),
    FOREIGN KEY (patient_id) REFERENCES patients(patient_id)
);
