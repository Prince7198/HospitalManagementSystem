package com.mycompany.healthlinkhospital.ui;

import com.mycompany.healthlinkhospital.dataaccess.UserDAO;
import com.mycompany.healthlinkhospital.service.User;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class LoginPage extends JFrame {

    private JTextField usernameField;
    private JPasswordField passwordField;
    private JButton loginButton;
    private JButton registerButton; // Added register button
    private UserDAO userDAO;

    public LoginPage() {
        // Set a better look and feel using UIManager (you can further customize this)
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Set up the JFrame
        setTitle("HealthLink Hospital - Login");
        setSize(400, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // Center the window on the screen

        // Initialize UserDAO (you should have this class implemented)
        userDAO = new UserDAO();

        // Create a panel with a 3x3 grid layout (added an extra row for the register button)
        JPanel panel = new JPanel(new GridLayout(3, 2));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // Create labels, input fields, and login button
        JLabel usernameLabel = new JLabel("Username:");
        JLabel passwordLabel = new JLabel("Password:");
        usernameField = new JTextField();
        passwordField = new JPasswordField();
        loginButton = new JButton("Login");
        registerButton = new JButton("Register"); // Added register button

        // Add components to the panel
        panel.add(usernameLabel);
        panel.add(usernameField);
        panel.add(new JLabel()); // Empty label for spacing

        panel.add(passwordLabel);
        panel.add(passwordField);

        panel.add(new JLabel()); // Empty label for spacing
        panel.add(loginButton);
        panel.add(new JLabel()); // Empty label for spacing
        panel.add(registerButton); // Added register button

        // Add the panel to the JFrame
        add(panel);

        // Add an ActionListener to the login button
        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Get username and password from the input fields
                String username = usernameField.getText();
                String password = new String(passwordField.getPassword());

                // Use the UserDAO to authenticate the user
                User user = userDAO.authenticateUser(username, password);

                if (user != null) {
                    // Redirect to the corresponding dashboard based on the user's role
                    redirectToDashboard(user);
                    JOptionPane.showMessageDialog(null, "Login successful!");
                } else {
                    JOptionPane.showMessageDialog(null, "Login failed. Please try again.");
                }

                // Clear the password field
                passwordField.setText("");
            }
        });

        // Add an ActionListener to the register button
        registerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Redirect to the registration page (you should implement this)
                redirectToRegistrationPage();
            }
        });
    }

    private void redirectToDashboard(User user) {
        switch (user.getRole()) {
            case "Admin":
                // Open the ReportsPage for Admin
                new ReportPage().setVisible(true);
                break;
            case "Doctor":
                // Open the DoctorPage for Doctors
                new DoctorPage(user.getUsername()).setVisible(true);
                break;
            case "Receptionist":
                // Open the ReceptionistPage for Receptionists
                new ReceptionistPage().setVisible(true);
                break;
            default:
                JOptionPane.showMessageDialog(null, "Unsupported user role.");
        }
    }

    private void redirectToRegistrationPage() {
        // Implement this method to open the registration page
        // For example: new RegistrationPage().setVisible(true);
        new RegistrationPage().setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new LoginPage().setVisible(true);
            }
        });
    }
}
