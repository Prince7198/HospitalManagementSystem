/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.healthlinkhospital.dataaccess;

import com.mycompany.healthlinkhospital.service.Patient;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class PatientDAO {
    private Connection connection;

    public PatientDAO() {
        try {
            connection = DatabaseConnector.getConnection();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Create a new patient record in the database.
    public boolean createPatient(Patient patient) {
        String sql = "INSERT INTO patients (first_name, last_name, date_of_birth, contact_number, email, address) " +
                     "VALUES (?, ?, ?, ?, ?, ?)";
        
        try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setString(1, patient.getFirstName());
            preparedStatement.setString(2, patient.getLastName());
            preparedStatement.setDate(3, new java.sql.Date(patient.getDateOfBirth().getTime()));
            preparedStatement.setString(4, patient.getContactNumber());
            preparedStatement.setString(5, patient.getEmail());
            preparedStatement.setString(6, patient.getAddress());

            int rowsAffected = preparedStatement.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Retrieve a patient record by ID.
    public Patient getPatientById(int patientId) {
        String sql = "SELECT * FROM patients WHERE patient_id = ?";
        
        try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setInt(1, patientId);

            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                return mapResultSetToPatient(resultSet);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return null;
    }

    // Retrieve a list of all patients in the database.
    public List<Patient> getAllPatients() {
        List<Patient> patients = new ArrayList<>();
        String sql = "SELECT * FROM patients";
        
        try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            ResultSet resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                patients.add(mapResultSetToPatient(resultSet));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return patients;
    }

    // Update an existing patient record in the database.
    public boolean updatePatient(Patient patient) {
        String sql = "UPDATE patients SET first_name = ?, last_name = ?, date_of_birth = ?, " +
                     "contact_number = ?, email = ?, address = ? WHERE patient_id = ?";
        
        try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setString(1, patient.getFirstName());
            preparedStatement.setString(2, patient.getLastName());
            preparedStatement.setDate(3, new java.sql.Date(patient.getDateOfBirth().getTime()));
            preparedStatement.setString(4, patient.getContactNumber());
            preparedStatement.setString(5, patient.getEmail());
            preparedStatement.setString(6, patient.getAddress());
            preparedStatement.setInt(7, patient.getPatientId());

            int rowsAffected = preparedStatement.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Delete a patient record by ID.
    public boolean deletePatient(int patientId) {
        String sql = "DELETE FROM patients WHERE patient_id = ?";
        
        try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setInt(1, patientId);

            int rowsAffected = preparedStatement.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Utility method to map a ResultSet row to a Patient object.
    private Patient mapResultSetToPatient(ResultSet resultSet) throws SQLException {
        Patient patient = new Patient();
        patient.setPatientId(resultSet.getInt("patient_id"));
        patient.setFirstName(resultSet.getString("first_name"));
        patient.setLastName(resultSet.getString("last_name"));
        patient.setDateOfBirth(resultSet.getDate("date_of_birth"));
        patient.setContactNumber(resultSet.getString("contact_number"));
        patient.setEmail(resultSet.getString("email"));
        patient.setAddress(resultSet.getString("address"));
        return patient;
    }
}
