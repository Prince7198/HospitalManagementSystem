/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.healthlinkhospital.ui;

import com.mycompany.healthlinkhospital.dataaccess.EHRDAO;
import com.mycompany.healthlinkhospital.dataaccess.PatientDAO;
import com.mycompany.healthlinkhospital.service.EHR;
import com.mycompany.healthlinkhospital.service.Patient;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class AddPatientEHRPage extends JFrame {
    private EHRDAO ehrDAO;
    private PatientDAO patientDAO;

    private JComboBox<Patient> patientComboBox;
    private JTextArea diagnosisTextArea;
    private JTextArea treatmentTextArea;
    private JTextArea medicalHistoryTextArea;
    private JTextArea allergiesTextArea;
    private JButton saveButton;

    public AddPatientEHRPage() {
        this.ehrDAO = new EHRDAO(); // Initialize EHRDAO
        this.patientDAO = new PatientDAO(); // Initialize PatientDAO

        setTitle("HealthLink Hospital - Electronic Health Record");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); // Close only this window
        setLocationRelativeTo(null);

        JPanel panel = new JPanel(new GridLayout(6, 2));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JLabel patientLabel = new JLabel("Patient:");
        JLabel diagnosisLabel = new JLabel("Diagnosis:");
        JLabel treatmentLabel = new JLabel("Treatment:");
        JLabel medicalHistoryLabel = new JLabel("Medical History:");
        JLabel allergiesLabel = new JLabel("Allergies:");

        // Populate the patient combo box with patient data
        java.util.List<Patient> patients = patientDAO.getAllPatients();
        patientComboBox = new JComboBox<>(patients.toArray(new Patient[0]));

        diagnosisTextArea = new JTextArea();
        treatmentTextArea = new JTextArea();
        medicalHistoryTextArea = new JTextArea();
        allergiesTextArea = new JTextArea();

        saveButton = new JButton("Save");

        panel.add(patientLabel);
        panel.add(patientComboBox);
        panel.add(diagnosisLabel);
        panel.add(new JScrollPane(diagnosisTextArea));
        panel.add(treatmentLabel);
        panel.add(new JScrollPane(treatmentTextArea));
        panel.add(medicalHistoryLabel);
        panel.add(new JScrollPane(medicalHistoryTextArea));
        panel.add(allergiesLabel);
        panel.add(new JScrollPane(allergiesTextArea));
        panel.add(new JLabel()); // Empty label for spacing
        panel.add(saveButton);

        add(panel);

        saveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Get selected patient and EHR details
                Patient selectedPatient = (Patient) patientComboBox.getSelectedItem();
                String diagnosis = diagnosisTextArea.getText();
                String treatment = treatmentTextArea.getText();
                String medicalHistory = medicalHistoryTextArea.getText();
                String allergies = allergiesTextArea.getText();

                // Create an EHR object and set its properties
                EHR ehr = new EHR();
                ehr.setPatientId(selectedPatient.getPatientId());
                ehr.setDiagnosis(diagnosis);
                ehr.setTreatment(treatment);
                ehr.setMedicalHistory(medicalHistory);
                ehr.setAllergies(allergies);

                // Save the EHR record to the database
                if (ehrDAO.createEHR(ehr)) {
                    JOptionPane.showMessageDialog(null, "EHR record added successfully!");
                    clearFields();
                } else {
                    JOptionPane.showMessageDialog(null, "Failed to add EHR record. Please try again.");
                }
            }
        });
    }

    private void clearFields() {
        diagnosisTextArea.setText("");
        treatmentTextArea.setText("");
        medicalHistoryTextArea.setText("");
        allergiesTextArea.setText("");
    }
     public static void main(String[] args) {
       SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new AddPatientEHRPage().setVisible(true);
            }
        });
    }
}

