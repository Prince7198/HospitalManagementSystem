/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.healthlinkhospital.ui;


import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ReceptionistPage extends JFrame {

    public ReceptionistPage() {
        setTitle("Receptionist Dashboard");
        setSize(400, 200);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel mainPanel = new JPanel(new GridLayout(2, 1));

        JButton managePatientsButton = new JButton("Manage Patients");
        JButton manageAppointmentsButton = new JButton("Manage Appointments");

        mainPanel.add(managePatientsButton);
        mainPanel.add(manageAppointmentsButton);

        managePatientsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                openManagePatientsPage();
            }
        });

        manageAppointmentsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                openManageAppointmentsPage();
            }
        });

        setContentPane(mainPanel);
    }

    private void openManagePatientsPage() {
        // Open the Manage Patients page
        new PatientManagementPage().setVisible(true);
    }

    private void openManageAppointmentsPage() {
        // Open the Manage Appointments page
        new ManageAppointmentsPage().setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new ReceptionistPage().setVisible(true);
            }
        });
    }
}

