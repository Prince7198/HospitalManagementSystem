/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.healthlinkhospital.ui;


import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnectionChecker extends JFrame {
    private JLabel statusLabel;

    public DatabaseConnectionChecker() {
        setTitle("Database Connection Checker");
        setSize(300, 100);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        statusLabel = new JLabel("Checking database connection...");
        statusLabel.setHorizontalAlignment(JLabel.CENTER);

        JButton checkButton = new JButton("Check Connection");
        checkButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                boolean isConnected = testDatabaseConnection();
                if (isConnected) {
                    statusLabel.setText("Database connection successful!");
                } else {
                    statusLabel.setText("Database connection failed!");
                }
            }
        });

        setLayout(new BorderLayout());
        add(statusLabel, BorderLayout.CENTER);
        add(checkButton, BorderLayout.SOUTH);
    }

    private boolean testDatabaseConnection() {
        String DB_URL = "jdbc:mysql://localhost:3306/healthlink_hospital";
        String DB_USER = "root";
        String DB_PASSWORD = "";

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            return connection != null && !connection.isClosed();
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                DatabaseConnectionChecker checker = new DatabaseConnectionChecker();
                checker.setVisible(true);
            }
        });
    }
}

