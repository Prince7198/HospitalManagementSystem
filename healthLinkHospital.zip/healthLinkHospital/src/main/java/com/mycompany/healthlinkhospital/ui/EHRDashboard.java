/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.healthlinkhospital.ui;

import com.mycompany.healthlinkhospital.dataaccess.EHRDAO;
import com.mycompany.healthlinkhospital.service.EHR;
import com.mycompany.healthlinkhospital.service.User;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class EHRDashboard extends JFrame {

    private EHRDAO ehrDAO;

    private JTextField searchField;
    private JButton searchButton;
    private JTable ehrTable;
    private JPanel mainPanel;
    private JButton addButton;
    private JButton editButton;
    private JButton deleteButton;

    public EHRDashboard() {
        this.ehrDAO = new EHRDAO(); // Initialize EHRDAO

        setTitle("HealthLink Hospital - EHR Dashboard");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        mainPanel = new JPanel(new BorderLayout());

        JPanel buttonPanel = new JPanel();
        addButton = new JButton("Add EHR");
        editButton = new JButton("Edit EHR");
        deleteButton = new JButton("Delete EHR");

        buttonPanel.add(addButton);
        buttonPanel.add(editButton);
        buttonPanel.add(deleteButton);
        // Create a panel for searching
        JPanel searchPanel = new JPanel(new BorderLayout());
        searchField = new JTextField();
        searchButton = new JButton("Search");
        searchPanel.add(searchField, BorderLayout.CENTER);
        searchPanel.add(searchButton, BorderLayout.EAST);

        // Create a table to display EHR records
        ehrTable = new JTable();
        JScrollPane tableScrollPane = new JScrollPane(ehrTable);
        panel.add(searchPanel, BorderLayout.NORTH);
        panel.add(tableScrollPane, BorderLayout.CENTER);
        mainPanel.add(buttonPanel, BorderLayout.NORTH);
        mainPanel.add(panel);
        // mainPanel.add(tableScrollPane, BorderLayout.CENTER);

        add(mainPanel);
        // add(panel);

        // Load EHR records on startup
        loadEHRRecords();
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Handle adding a new EHR record
                new AddPatientEHRPage().setVisible(true);
            }
        });
        editButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Handle editing the selected EHR record
                int selectedRow = ehrTable.getSelectedRow();
                if (selectedRow >= 0) {
                    // Get the selected EHR record and open an edit dialog
                    //  EHR selectedEHR = ehrList.get(selectedRow);
                    // openEditEHRDialog(selectedEHR);
                } else {
                    JOptionPane.showMessageDialog(EHRDashboard.this, "Please select an EHR to edit.");
                }
            }
        });
        deleteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Handle deleting the selected EHR record
                int selectedRow = ehrTable.getSelectedRow();
                if (selectedRow >= 0) {
                    // Get the selected EHR record and confirm deletion
                    // EHR selectedEHR = ehrList.get(selectedRow);
                    int confirm = JOptionPane.showConfirmDialog(
                            EHRDashboard.this,
                            "Are you sure you want to delete this EHR record?",
                            "Confirm Delete",
                            JOptionPane.YES_NO_OPTION);

                    if (confirm == JOptionPane.YES_OPTION) {
                        // Perform the deletion and update the table
                        // boolean deleted = new EHRDAO().deleteEHR(selectedEHR);
                        // if (deleted) {
                        //     ehrList.remove(selectedEHR);
                        //     model.fireTableDataChanged();
                        // }
                    }
                } else {
                    JOptionPane.showMessageDialog(EHRDashboard.this, "Please select an EHR to delete.");
                }
            }
        });
        searchButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String searchText = searchField.getText();
                searchEHRRecords(searchText);
            }
        });
    }

    private void loadEHRRecords() {
        // Get all EHR records
        List<EHR> ehrList = ehrDAO.getAllEHRs();

        // Create a table model to display EHR records
        DefaultTableModel tableModel = new DefaultTableModel();
        tableModel.addColumn("Patient ID");
        tableModel.addColumn("Diagnosis");
        tableModel.addColumn("Treatment");
        tableModel.addColumn("Medical History");
        tableModel.addColumn("Allergies");

        for (EHR ehr : ehrList) {
            Object[] rowData = {
                ehr.getPatientId(),
                ehr.getDiagnosis(),
                ehr.getTreatment(),
                ehr.getMedicalHistory(),
                ehr.getAllergies()
            };
            tableModel.addRow(rowData);
        }

        // Set the table model
        ehrTable.setModel(tableModel);
    }

    private void searchEHRRecords(String searchText) {
        // Get EHR records based on the search text
        List<EHR> ehrList = ehrDAO.searchEHRs(searchText);

        // Create a table model to display search results
        DefaultTableModel tableModel = new DefaultTableModel();
        tableModel.addColumn("Patient ID");
        tableModel.addColumn("Diagnosis");
        tableModel.addColumn("Treatment");
        tableModel.addColumn("Medical History");
        tableModel.addColumn("Allergies");

        for (EHR ehr : ehrList) {
            Object[] rowData = {
                ehr.getPatientId(),
                ehr.getDiagnosis(),
                ehr.getTreatment(),
                ehr.getMedicalHistory(),
                ehr.getAllergies()
            };
            tableModel.addRow(rowData);
        }

        // Set the table model
        ehrTable.setModel(tableModel);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                // For testing purposes, you can create a dummy user.
                User user = new User();
                user.setRole("admin"); // Set the role as 'admin' or 'doctor' for testing
                new EHRDashboard().setVisible(true);
            }
        });
    }
}
