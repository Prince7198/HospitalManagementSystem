package com.mycompany.healthlinkhospital.ui;


import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class ReportPage extends JFrame {

    private JPanel mainPanel;
    private JPanel usersPanel;
    private JPanel patientsPanel;
    private JPanel appointmentsPanel;
    private JPanel doctorsPanel;
    private JPanel ehrPanel;


    public ReportPage() {
        setSize(800, 800);

        mainPanel = new JPanel(new GridLayout(2, 2));
        usersPanel = createReportContainer("Users");
        patientsPanel = createReportContainer("Patients");
        appointmentsPanel = createReportContainer("Appointments");
        doctorsPanel = createReportContainer("Doctors");
        ehrPanel = createReportContainer("EHR");


        mainPanel.add(usersPanel);
        mainPanel.add(patientsPanel);
        mainPanel.add(appointmentsPanel);
        mainPanel.add(doctorsPanel);
        mainPanel.add(ehrPanel);


        setContentPane(mainPanel);

        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
    }

    private JPanel createReportContainer(String groupName) {
        JPanel panel = new JPanel();
        panel.setBorder(BorderFactory.createTitledBorder(groupName));
        panel.setLayout(new BorderLayout());

        JLabel summaryLabel = new JLabel("Summary: Total " + groupName + " = 0");
        JButton manageButton = new JButton("Manage " + groupName);

        panel.add(summaryLabel, BorderLayout.NORTH);
        panel.add(manageButton, BorderLayout.CENTER);

        manageButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                openManagementPage(groupName);
            }
        });

        return panel;
    }

    private void openManagementPage(String groupName) {
        if ("Users".equals(groupName)) {
            // Open the Manage Users page
            new ManageUsersDashboard().setVisible(true);
        } else if ("Patients".equals(groupName)) {
            // Open the Manage Patients page
            new PatientManagementPage().setVisible(true);
        } else if ("Appointments".equals(groupName)) {
            // Open the Manage Appointments page
            new ManageAppointmentsPage().setVisible(true);
        } 
        else if ("EHR".equals(groupName)) {
            // Open the Manage Appointments page
            new EHRDashboard().setVisible(true);
        } 
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new ReportPage().setVisible(true);
            }
        });
    }
}
