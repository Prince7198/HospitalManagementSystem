/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.healthlinkhospital.ui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class AddPaymentPage extends JFrame {
    private JTextField patientIdField;
    private JTextField paymentDateField;
    private JTextField amountField;
    private JTextField paymentMethodField;
    private JButton submitButton;

    public AddPaymentPage() {
        setTitle("HealthLink Hospital - Add Payment");
        setSize(400, 200);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); // Close this window, but keep the main window open
        setLocationRelativeTo(null); // Center the window on the screen

        // Create a panel with a BorderLayout
        JPanel mainPanel = new JPanel(new GridLayout(5, 2));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JLabel patientIdLabel = new JLabel("Patient ID:");
        JLabel paymentDateLabel = new JLabel("Payment Date:");
        JLabel amountLabel = new JLabel("Amount:");
        JLabel paymentMethodLabel = new JLabel("Payment Method:");

        patientIdField = new JTextField();
        paymentDateField = new JTextField();
        amountField = new JTextField();
        paymentMethodField = new JTextField();

        submitButton = new JButton("Submit Payment");

        mainPanel.add(patientIdLabel);
        mainPanel.add(patientIdField);
        mainPanel.add(paymentDateLabel);
        mainPanel.add(paymentDateField);
        mainPanel.add(amountLabel);
        mainPanel.add(amountField);
        mainPanel.add(paymentMethodLabel);
        mainPanel.add(paymentMethodField);
        mainPanel.add(new JLabel()); // Empty label for spacing
        mainPanel.add(submitButton);

        add(mainPanel);

        submitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Get the payment details from the input fields
                String patientId = patientIdField.getText();
                String paymentDate = paymentDateField.getText();
                String amount = amountField.getText();
                String paymentMethod = paymentMethodField.getText();

                // Validate and process the payment data, e.g., save it to the database
                // You can use a PaymentDAO class for database operations.

                // Close the "Add Payment" window after submission
                dispose();
            }
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new AddPaymentPage().setVisible(true);
            }
        });
    }
}
