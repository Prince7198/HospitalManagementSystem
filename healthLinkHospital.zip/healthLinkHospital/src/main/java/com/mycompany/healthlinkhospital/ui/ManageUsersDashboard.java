/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.healthlinkhospital.ui;

import com.mycompany.healthlinkhospital.dataaccess.UserDAO;
import com.mycompany.healthlinkhospital.service.User;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class ManageUsersDashboard extends JFrame {
    private JTable usersTable;
    private JButton addButton;
    private JButton editButton;
    private JButton deleteButton;

    public ManageUsersDashboard() {
        setTitle("Manage Users Dashboard");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel mainPanel = new JPanel(new BorderLayout());

        // Create a table to display user records
        String[] columnNames = {"ID", "User Name", "Role"};
        DefaultTableModel model = new DefaultTableModel(columnNames, 0);
        usersTable = new JTable(model);

        JScrollPane tableScrollPane = new JScrollPane(usersTable);
        mainPanel.add(tableScrollPane, BorderLayout.CENTER);

        // Create buttons for Add, Edit, and Delete
        addButton = new JButton("Add User");
        editButton = new JButton("Edit User");
        deleteButton = new JButton("Delete User");

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(addButton);
        buttonPanel.add(editButton);
        buttonPanel.add(deleteButton);
        mainPanel.add(buttonPanel, BorderLayout.SOUTH);

        // Load user data into the table
        loadUserData();

        // Add action listeners for the buttons
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Navigate to the Add User page
                AddUserPage addUserPage = new AddUserPage("admin");
                addUserPage.setVisible(true);
            }
        });

        editButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Get the selected user and open the Edit User page
                int selectedRow = usersTable.getSelectedRow();
                if (selectedRow >= 0) {
                    int userId = (int) usersTable.getValueAt(selectedRow, 0);
                    UserDAO userDAO = new UserDAO();
                    User user = userDAO.getUserById(userId);

                    if (user != null) {
                        EditUserPage editUserPage = new EditUserPage(user);
                        editUserPage.setVisible(true);
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Please select a user to edit.");
                }
            }
        });

        deleteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Get the selected user and delete it
                int selectedRow = usersTable.getSelectedRow();
                if (selectedRow >= 0) {
                    int userId = (int) usersTable.getValueAt(selectedRow, 0);
                    UserDAO userDAO = new UserDAO();
                    
                    if (userDAO.deleteUser(userId)) {
                        // User deleted successfully, remove it from the table
                        model.removeRow(selectedRow);
                    } else {
                        JOptionPane.showMessageDialog(null, "Failed to delete the user.");
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Please select a user to delete.");
                }
            }
        });

        setContentPane(mainPanel);
    }

    private void loadUserData() {
        // Fetch user data from the database and populate the table
        UserDAO userDAO = new UserDAO();
        List<User> users = userDAO.getAllUsers();

        DefaultTableModel model = (DefaultTableModel) usersTable.getModel();
        for (User user : users) {
            model.addRow(new Object[]{user.getUserId(), user.getUsername(), user.getRole()});
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new ManageUsersDashboard().setVisible(true);
            }
        });
    }
}

