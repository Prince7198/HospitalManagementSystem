/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.healthlinkhospital.ui;

import com.mycompany.healthlinkhospital.dataaccess.UserDAO;
import com.mycompany.healthlinkhospital.service.User;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class EditUserPage extends JFrame {
    private User user;
    private UserDAO userDAO;

    private JTextField usernameField;
    private JPasswordField passwordField;
    private JTextField roleField;
    private JButton saveButton;

    public EditUserPage(User user) {
        this.user = user;
        this.userDAO = new UserDAO(); // Initialize UserDAO

        setTitle("HealthLink Hospital - Edit User");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel(new GridLayout(4, 2));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JLabel usernameLabel = new JLabel("Username:");
        JLabel passwordLabel = new JLabel("Password:");
        JLabel roleLabel = new JLabel("Role:");

        usernameField = new JTextField(user.getUsername());
        passwordField = new JPasswordField();
        roleField = new JTextField(user.getRole());

        saveButton = new JButton("Save Changes");

        panel.add(usernameLabel);
        panel.add(usernameField);
        panel.add(passwordLabel);
        panel.add(passwordField);
        panel.add(roleLabel);
        panel.add(roleField);
        panel.add(new JLabel()); // Empty label for spacing
        panel.add(saveButton);

        add(panel);

        saveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Update the user model with edited data
                user.setUsername(usernameField.getText());

                // Check if a new password is set
                char[] newPassword = passwordField.getPassword();
                if (newPassword.length > 0) {
                    user.setPassword(new String(newPassword));
                }

                user.setRole(roleField.getText());

                // Update the user in the database
                if (userDAO.updateUser(user)) {
                    JOptionPane.showMessageDialog(null, "User updated successfully!");
                    dispose(); // Close this window
                } else {
                    JOptionPane.showMessageDialog(null, "Failed to update user. Please try again.");
                }
            }
        });
    }
}

