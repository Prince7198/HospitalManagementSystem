package com.mycompany.healthlinkhospital.ui;

import com.mycompany.healthlinkhospital.dataaccess.AppointmentDAO;
import com.mycompany.healthlinkhospital.dataaccess.AppointmentTableModel;
import com.mycompany.healthlinkhospital.service.Appointment;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

public class ManageAppointmentsPage extends JFrame {
    private JButton addButton;
    private JButton editButton;
    private JButton deleteButton;
    private JTable appointmentTable;

    public ManageAppointmentsPage() {
        setTitle("HealthLink Hospital - Manage Appointments");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel mainPanel = new JPanel(new BorderLayout());

        JPanel buttonPanel = new JPanel();
        addButton = new JButton("Add Appointment");
        editButton = new JButton("Edit Appointment");
        deleteButton = new JButton("Delete Appointment");

        buttonPanel.add(addButton);
        buttonPanel.add(editButton);
        buttonPanel.add(deleteButton);

        // Create a JTable for displaying appointment records
        String[] columnNames = {"ID", "Patient", "Doctor", "Appointment Date", "Status"};

        // Fetch appointment data from the database using the AppointmentDAO
        List<Appointment> appointments = new AppointmentDAO().getAllAppointments();

        // Create a custom table model
        AppointmentTableModel model = new AppointmentTableModel(appointments, columnNames);
        appointmentTable = new JTable(model);

        // Add the table to a scroll pane
        JScrollPane tableScrollPane = new JScrollPane(appointmentTable);

        mainPanel.add(buttonPanel, BorderLayout.NORTH);
        mainPanel.add(tableScrollPane, BorderLayout.CENTER);

        add(mainPanel);

        // Add action listeners for buttons
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Open the Add Appointment page
                new AddApointmentPage().setVisible(true);
            }
        });

        editButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedRow = appointmentTable.getSelectedRow();
                if (selectedRow != -1) {
                    // Get the selected appointment
                    Appointment selectedAppointment = appointments.get(selectedRow);
                    // Open the Edit Appointment page with the selected appointment
                    new EditAppointmentPage(selectedAppointment).setVisible(true);
                } else {
                    JOptionPane.showMessageDialog(null, "Please select an appointment to edit.");
                }
            }
        });

        deleteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedRow = appointmentTable.getSelectedRow();
                if (selectedRow != -1) {
                    // Get the selected appointment
                    Appointment selectedAppointment = appointments.get(selectedRow);
                    // Show a confirmation dialog
                    int choice = JOptionPane.showConfirmDialog(null, "Are you sure you want to delete this appointment?", "Delete Appointment", JOptionPane.YES_NO_OPTION);
                    if (choice == JOptionPane.YES_OPTION) {
                        // Delete the selected appointment
                        boolean isDeleted = new AppointmentDAO().deleteAppointment(selectedAppointment.getAppointmentId());
                        if (isDeleted) {
                            // Remove the deleted appointment from the table and update the UI
                            appointments.remove(selectedAppointment);
                            model.fireTableDataChanged();
                            JOptionPane.showMessageDialog(null, "Appointment deleted successfully.");
                        } else {
                            JOptionPane.showMessageDialog(null, "Failed to delete the appointment.");
                        }
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Please select an appointment to delete.");
                }
            }
        });

        // Enable/disable the Edit and Delete buttons based on table selection
        appointmentTable.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                int selectedRow = appointmentTable.getSelectedRow();
                editButton.setEnabled(selectedRow != -1);
                deleteButton.setEnabled(selectedRow != -1);
            }
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new ManageAppointmentsPage().setVisible(true);
            }
        });
    }
}
