/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.healthlinkhospital.ui;

/**
 *
 * @author Mtundi
 */
import com.mycompany.healthlinkhospital.dataaccess.UserDAO;
import com.mycompany.healthlinkhospital.service.User;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class RegistrationPage extends JFrame {
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JComboBox<String> roleComboBox;
    private JButton registerButton;
    private UserDAO userDAO;

    public RegistrationPage() {
        // Set up the JFrame
        setTitle("HealthLink Hospital - Registration");
        setSize(400, 200);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        // Initialize UserDAO (you should have this class implemented)
        userDAO = new UserDAO();

        // Create a panel with a 3x2 grid layout
        JPanel panel = new JPanel(new GridLayout(4, 2));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // Create labels, input fields, and register button
        JLabel usernameLabel = new JLabel("Username:");
        JLabel passwordLabel = new JLabel("Password:");
        JLabel roleLabel = new JLabel("Role:");
        usernameField = new JTextField();
        passwordField = new JPasswordField();
        String[] roles = {"Doctor", "Receptionist", "Admin"};
        roleComboBox = new JComboBox<>(roles);
        registerButton = new JButton("Register");

        // Add components to the panel
        panel.add(usernameLabel);
        panel.add(usernameField);
        panel.add(passwordLabel);
        panel.add(passwordField);
        panel.add(roleLabel);
        panel.add(roleComboBox);
        panel.add(new JLabel()); // Empty label for spacing
        panel.add(registerButton);

        // Add the panel to the JFrame
        add(panel);

        // Add an ActionListener to the register button
        registerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Get user registration information from input fields
                String username = usernameField.getText();
                String password = new String(passwordField.getPassword());
                String role = (String) roleComboBox.getSelectedItem();

                // Create a new User object and pass it to the UserDAO for registration
                User newUser = new User(username, password, role);
                boolean registrationSuccessful = userDAO.createUser(newUser);

                if (registrationSuccessful) {
                    JOptionPane.showMessageDialog(null, "Registration successful!");
                    // Optionally, you can close this registration window and proceed to login
                    dispose();
                } else {
                    JOptionPane.showMessageDialog(null, "Registration failed. Please try again.");
                }

                // Clear the input fields
                usernameField.setText("");
                passwordField.setText("");
            }
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new RegistrationPage().setVisible(true);
            }
        });
    }
}

