/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.healthlinkhospital.service;

import com.mycompany.healthlinkhospital.dataaccess.PatientDAO;
import com.mycompany.healthlinkhospital.dataaccess.UserDAO;
import java.util.Date;

public class Appointment {
    private int appointmentId;
    private int patientId;
    private int doctorId;
    private Date appointmentDate;
    private String status;

    public Appointment(int appointmentId, int patientId, int doctorId, Date appointmentDate, String status) {
        this.doctorId=doctorId;
        this.patientId=patientId;
        this.appointmentDate = appointmentDate;
        this.appointmentId = appointmentId;
        this.status=status;
    }

    public Appointment(int selectedPatient, int selectedDoctor, Date appointmentDate, String status) {
        this.patientId=selectedPatient;
        this.doctorId = selectedDoctor;
        this.appointmentDate=appointmentDate;
        this.status = status;
    }

    // Getters and Setters for appointmentId
    public int getAppointmentId() {
        return appointmentId;
    }

    public void setAppointmentId(int appointmentId) {
        this.appointmentId = appointmentId;
    }

    // Getters and Setters for patientId
    public int getPatientId() {
        return patientId;
    }
    public String getPatientName(){
        return new PatientDAO().getPatientById(patientId).toString();
    }
    public String getDoctorName(){
        return new UserDAO().getUserById(doctorId).toString();
    }
    public void setPatientId(int patientId) {
        this.patientId = patientId;
    }

    // Getters and Setters for doctorId
    public int getDoctorId() {
        return doctorId;
    }

    public void setDoctorId(int doctorId) {
        this.doctorId = doctorId;
    }

    // Getters and Setters for appointmentDate
    public Date getAppointmentDate() {
        return appointmentDate;
    }

    public void setAppointmentDate(Date appointmentDate) {
        this.appointmentDate = appointmentDate;
    }

    // Getters and Setters for status
    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}

