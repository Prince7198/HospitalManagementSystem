/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.healthlinkhospital.ui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class AddInvoicePage extends JFrame {
    private JTextField patientIdField;
    private JTextField invoiceDateField;
    private JTextField amountField;
    private JTextField statusField;
    private JButton submitButton;

    public AddInvoicePage() {
        setTitle("HealthLink Hospital - Add Invoice");
        setSize(400, 200);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); // Close this window, but keep the main window open
        setLocationRelativeTo(null); // Center the window on the screen

        // Create a panel with a BorderLayout
        JPanel mainPanel = new JPanel(new GridLayout(5, 2));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JLabel patientIdLabel = new JLabel("Patient ID:");
        JLabel invoiceDateLabel = new JLabel("Invoice Date:");
        JLabel amountLabel = new JLabel("Amount:");
        JLabel statusLabel = new JLabel("Status:");

        patientIdField = new JTextField();
        invoiceDateField = new JTextField();
        amountField = new JTextField();
        statusField = new JTextField();

        submitButton = new JButton("Submit Invoice");

        mainPanel.add(patientIdLabel);
        mainPanel.add(patientIdField);
        mainPanel.add(invoiceDateLabel);
        mainPanel.add(invoiceDateField);
        mainPanel.add(amountLabel);
        mainPanel.add(amountField);
        mainPanel.add(statusLabel);
        mainPanel.add(statusField);
        mainPanel.add(new JLabel()); // Empty label for spacing
        mainPanel.add(submitButton);

        add(mainPanel);

        submitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Get the invoice details from the input fields
                String patientId = patientIdField.getText();
                String invoiceDate = invoiceDateField.getText();
                String amount = amountField.getText();
                String status = statusField.getText();

                // Validate and process the invoice data, e.g., save it to the database
                // You can use an InvoiceDAO class for database operations.

                // Close the "Add Invoice" window after submission
                dispose();
            }
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new AddInvoicePage().setVisible(true);
            }
        });
    }
}

