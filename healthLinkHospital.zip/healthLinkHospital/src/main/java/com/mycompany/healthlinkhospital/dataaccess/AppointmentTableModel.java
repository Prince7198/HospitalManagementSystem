/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.healthlinkhospital.dataaccess;

import com.mycompany.healthlinkhospital.service.Appointment;
import java.text.SimpleDateFormat;
import java.util.List;
import javax.swing.table.AbstractTableModel;

public class AppointmentTableModel extends AbstractTableModel {
    private List<Appointment> appointments;
    private String[] columnNames;

    public AppointmentTableModel(List<Appointment> appointments, String[] columnNames) {
        this.appointments = appointments;
        this.columnNames = columnNames;
    }

    @Override
    public int getRowCount() {
        return appointments.size();
    }

    @Override
    public int getColumnCount() {
        return columnNames.length;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Appointment appointment = appointments.get(rowIndex);

        switch (columnIndex) {
            case 0: // ID
                return appointment.getAppointmentId();
            case 1: // Patient
                return appointment.getPatientId(); // You can replace with patient name
            case 2: // Doctor
                return appointment.getDoctorId(); // You can replace with doctor name
            case 3: // Appointment Date
                SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                return dateFormat.format(appointment.getAppointmentDate());
            case 4: // Status
                return appointment.getStatus();
            default:
                return null;
        }
    }

    @Override
    public String getColumnName(int column) {
        return columnNames[column];
    }
}
