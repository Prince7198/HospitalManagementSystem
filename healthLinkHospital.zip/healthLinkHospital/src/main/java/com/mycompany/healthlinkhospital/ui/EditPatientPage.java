/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.healthlinkhospital.ui;

import com.mycompany.healthlinkhospital.dataaccess.PatientDAO;
import com.mycompany.healthlinkhospital.service.Patient;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class EditPatientPage extends JFrame {
    private Patient patient;
    private PatientDAO patientDAO;

    private JTextField firstNameField;
    private JTextField lastNameField;
    private JTextField dobField;
    private JTextField contactNumberField;
    private JTextField emailField;
    private JTextField addressField;
    private JButton saveButton;

    public EditPatientPage(int patientID) {
        this.patientDAO = new PatientDAO(); // Initialize PatientDAO
           this.patient = patientDAO.getPatientById(patientID);

        setTitle("HealthLink Hospital - Edit Patient");
        setSize(400, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); // Close only this window
        setLocationRelativeTo(null);

        JPanel panel = new JPanel(new GridLayout(7, 2));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JLabel firstNameLabel = new JLabel("First Name:");
        JLabel lastNameLabel = new JLabel("Last Name:");
        JLabel dobLabel = new JLabel("Date of Birth:");
        JLabel contactNumberLabel = new JLabel("Contact Number:");
        JLabel emailLabel = new JLabel("Email:");
        JLabel addressLabel = new JLabel("Address:");

        firstNameField = new JTextField(patient.getFirstName());
        lastNameField = new JTextField(patient.getLastName());
        dobField = new JTextField(patient.getDateOfBirth().toString());
        contactNumberField = new JTextField(patient.getContactNumber());
        emailField = new JTextField(patient.getEmail());
        addressField = new JTextField(patient.getAddress());

        saveButton = new JButton("Save Changes");

        panel.add(firstNameLabel);
        panel.add(firstNameField);
        panel.add(lastNameLabel);
        panel.add(lastNameField);
        panel.add(dobLabel);
        panel.add(dobField);
        panel.add(contactNumberLabel);
        panel.add(contactNumberField);
        panel.add(emailLabel);
        panel.add(emailField);
        panel.add(addressLabel);
        panel.add(addressField);
        panel.add(new JLabel()); // Empty label for spacing
        panel.add(saveButton);

        add(panel);

        saveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Update the patient model with edited data
                patient.setFirstName(firstNameField.getText());
                patient.setLastName(lastNameField.getText());
                // Parse date of birth and set it in the patient model
                // patient.setDateOfBirth(...);
                patient.setContactNumber(contactNumberField.getText());
                patient.setEmail(emailField.getText());
                patient.setAddress(addressField.getText());

                // Update the patient in the database
                if (patientDAO.updatePatient(patient)) {
                    JOptionPane.showMessageDialog(null, "Patient updated successfully!");
                    dispose(); // Close this window
                } else {
                    JOptionPane.showMessageDialog(null, "Failed to update patient. Please try again.");
                }
            }
        });
    }
}
