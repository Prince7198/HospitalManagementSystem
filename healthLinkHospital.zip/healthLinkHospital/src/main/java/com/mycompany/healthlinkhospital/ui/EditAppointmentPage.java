/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.healthlinkhospital.ui;

import com.mycompany.healthlinkhospital.dataaccess.AppointmentDAO;
import com.mycompany.healthlinkhospital.service.Appointment;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class EditAppointmentPage extends JFrame {
    private Appointment appointment;
    private AppointmentDAO appointmentDAO;

    private JTextField patientField;
    private JTextField doctorField;
    private JTextField appointmentDateField;
    private JTextField statusField;
    private JButton saveButton;

    public EditAppointmentPage(Appointment appointment) {
        this.appointment = appointment;
        this.appointmentDAO = new AppointmentDAO(); // Initialize AppointmentDAO

        setTitle("HealthLink Hospital - Edit Appointment");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); // Close only this window
        setLocationRelativeTo(null);

        JPanel panel = new JPanel(new GridLayout(5, 2));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JLabel patientLabel = new JLabel("Patient:");
        JLabel doctorLabel = new JLabel("Doctor:");
        JLabel appointmentDateLabel = new JLabel("Appointment Date:");
        JLabel statusLabel = new JLabel("Status:");

        patientField = new JTextField(appointment.getPatientName());
        doctorField = new JTextField(appointment.getDoctorName());
        appointmentDateField = new JTextField(appointment.getAppointmentDate().toString());
        statusField = new JTextField(appointment.getStatus());

        saveButton = new JButton("Save Changes");

        panel.add(patientLabel);
        panel.add(patientField);
        panel.add(doctorLabel);
        panel.add(doctorField);
        panel.add(appointmentDateLabel);
        panel.add(appointmentDateField);
        panel.add(statusLabel);
        panel.add(statusField);
        panel.add(new JLabel()); // Empty label for spacing
        panel.add(saveButton);

        add(panel);

        saveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Update the appointment model with edited data
                appointment.setPatientId(Integer.parseInt(patientField.getText()));
                appointment.setDoctorId(Integer.parseInt(doctorField.getText()));
                // Parse appointment date and set it in the appointment model
                // appointment.setAppointmentDate(...);
                appointment.setStatus(statusField.getText());

                // Update the appointment in the database
                if (appointmentDAO.updateAppointment(appointment)) {
                    JOptionPane.showMessageDialog(null, "Appointment updated successfully!");
                    dispose(); // Close this window
                } else {
                    JOptionPane.showMessageDialog(null, "Failed to update appointment. Please try again.");
                }
            }
        });
    }
}

