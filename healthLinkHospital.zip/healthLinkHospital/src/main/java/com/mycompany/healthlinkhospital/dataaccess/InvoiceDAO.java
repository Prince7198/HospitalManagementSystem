/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.healthlinkhospital.dataaccess;

import com.mycompany.healthlinkhospital.service.Invoice;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class InvoiceDAO {
    private Connection connection;

    public InvoiceDAO() {
        try {
            connection = DatabaseConnector.getConnection();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public boolean createInvoice(Invoice invoice) {
        String sql = "INSERT INTO invoices (patient_id, invoice_date, amount, status) " +
                     "VALUES (?, ?, ?, ?)";

        try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setInt(1, invoice.getPatientId());
            preparedStatement.setDate(2, new java.sql.Date(invoice.getInvoiceDate().getTime()));
            preparedStatement.setBigDecimal(3, invoice.getAmount());
            preparedStatement.setString(4, invoice.getStatus());

            int rowsAffected = preparedStatement.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public Invoice getInvoiceById(int invoiceId) {
        String sql = "SELECT * FROM invoices WHERE invoice_id = ?";

        try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setInt(1, invoiceId);

            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                return mapResultSetToInvoice(resultSet);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return null;
    }

    public List<Invoice> getAllInvoices() {
        List<Invoice> invoices = new ArrayList<>();
        String sql = "SELECT * FROM invoices";

        try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            ResultSet resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                invoices.add(mapResultSetToInvoice(resultSet));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return invoices;
    }

    public boolean updateInvoice(Invoice invoice) {
        String sql = "UPDATE invoices SET patient_id = ?, invoice_date = ?, " +
                     "amount = ?, status = ? WHERE invoice_id = ?";

        try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setInt(1, invoice.getPatientId());
            preparedStatement.setDate(2, new java.sql.Date(invoice.getInvoiceDate().getTime()));
            preparedStatement.setBigDecimal(3, invoice.getAmount());
            preparedStatement.setString(4, invoice.getStatus());
            preparedStatement.setInt(5, invoice.getInvoiceId());

            int rowsAffected = preparedStatement.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean deleteInvoice(int invoiceId) {
        String sql = "DELETE FROM invoices WHERE invoice_id = ?";

        try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setInt(1, invoiceId);

            int rowsAffected = preparedStatement.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    private Invoice mapResultSetToInvoice(ResultSet resultSet) throws SQLException {
        Invoice invoice = new Invoice();
        invoice.setInvoiceId(resultSet.getInt("invoice_id"));
        invoice.setPatientId(resultSet.getInt("patient_id"));
        invoice.setInvoiceDate(resultSet.getDate("invoice_date"));
        invoice.setAmount(resultSet.getBigDecimal("amount"));
        invoice.setStatus(resultSet.getString("status"));
        return invoice;
    }
}
