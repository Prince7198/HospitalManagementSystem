/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.healthlinkhospital.dataaccess;

import com.mycompany.healthlinkhospital.service.Patient;
import javax.swing.table.AbstractTableModel;
import java.util.List;

public class PatientTableModel extends AbstractTableModel {
    private List<Patient> data;
    private String[] columnNames;

    public PatientTableModel(List<Patient> data, String[] columnNames) {
        this.data = data;
        this.columnNames = columnNames;
    }

    @Override
    public int getRowCount() {
        return data.size();
    }

    @Override
    public int getColumnCount() {
        return columnNames.length;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Patient patient = data.get(rowIndex);
        switch (columnIndex) {
            case 0:
                return patient.getPatientId();
            case 1:
                return patient.getFirstName();
            case 2:
                return patient.getLastName();
            case 3:
                return patient.getDateOfBirth();
            case 4:
                return patient.getContactNumber();
            case 5:
                return patient.getEmail();
            case 6:
                return patient.getAddress();
            default:
                return null;
        }
    }

    @Override
    public String getColumnName(int column) {
        return columnNames[column];
    }
}

