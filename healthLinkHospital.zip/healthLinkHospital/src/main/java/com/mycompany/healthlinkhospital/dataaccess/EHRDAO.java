/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.healthlinkhospital.dataaccess;

import com.mycompany.healthlinkhospital.service.EHR;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class EHRDAO {
    private Connection connection;

    public EHRDAO() {
        try {
            connection = DatabaseConnector.getConnection();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public boolean createEHR(EHR ehr) {
        String sql = "INSERT INTO ehrs (patient_id, diagnosis, treatment, medical_history, allergies) " +
                     "VALUES (?, ?, ?, ?, ?)";

        try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setInt(1, ehr.getPatientId());
            preparedStatement.setString(2, ehr.getDiagnosis());
            preparedStatement.setString(3, ehr.getTreatment());
            preparedStatement.setString(4, ehr.getMedicalHistory());
            preparedStatement.setString(5, ehr.getAllergies());

            int rowsAffected = preparedStatement.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public EHR getEHRById(int ehrId) {
        String sql = "SELECT * FROM ehrs WHERE ehr_id = ?";

        try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setInt(1, ehrId);

            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                return mapResultSetToEHR(resultSet);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return null;
    }

    public List<EHR> getAllEHRsForPatient(int patientId) {
        List<EHR> ehrs = new ArrayList<>();
        String sql = "SELECT * FROM ehrs WHERE patient_id = ?";

        try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setInt(1, patientId);

            ResultSet resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                ehrs.add(mapResultSetToEHR(resultSet));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return ehrs;
    }
    
    public List<EHR> getAllEHRs() {
        List<EHR> ehrs = new ArrayList<>();
        String sql = "SELECT * FROM ehrs ";

        try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {

            ResultSet resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                ehrs.add(mapResultSetToEHR(resultSet));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return ehrs;
    }

    public boolean updateEHR(EHR ehr) {
        String sql = "UPDATE ehrs SET patient_id = ?, diagnosis = ?, treatment = ?, " +
                     "medical_history = ?, allergies = ? WHERE ehr_id = ?";

        try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setInt(1, ehr.getPatientId());
            preparedStatement.setString(2, ehr.getDiagnosis());
            preparedStatement.setString(3, ehr.getTreatment());
            preparedStatement.setString(4, ehr.getMedicalHistory());
            preparedStatement.setString(5, ehr.getAllergies());
            preparedStatement.setInt(6, ehr.getEhrId());

            int rowsAffected = preparedStatement.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean deleteEHR(int ehrId) {
        String sql = "DELETE FROM ehrs WHERE ehr_id = ?";

        try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setInt(1, ehrId);

            int rowsAffected = preparedStatement.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
        public List<EHR> searchEHRs(String searchText) {
        List<EHR> ehrs = new ArrayList<>();
        String sql = "SELECT * FROM ehrs WHERE patient_id IN (SELECT patient_id FROM patients WHERE first_name LIKE ? OR last_name LIKE ?)";

        try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setString(1, "%" + searchText + "%");
            preparedStatement.setString(2, "%" + searchText + "%");

            ResultSet resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                ehrs.add(mapResultSetToEHR(resultSet));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return ehrs;
    }

    private EHR mapResultSetToEHR(ResultSet resultSet) throws SQLException {
        EHR ehr = new EHR();
        ehr.setEhrId(resultSet.getInt("ehr_id"));
        ehr.setPatientId(resultSet.getInt("patient_id"));
        ehr.setDiagnosis(resultSet.getString("diagnosis"));
        ehr.setTreatment(resultSet.getString("treatment"));
        ehr.setMedicalHistory(resultSet.getString("medical_history"));
        ehr.setAllergies(resultSet.getString("allergies"));
        return ehr;
    }
}

