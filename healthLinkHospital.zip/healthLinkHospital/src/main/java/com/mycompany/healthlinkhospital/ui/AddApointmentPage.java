/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.healthlinkhospital.ui;

/**
 *
 * @author Mtundi
 */

import com.mycompany.healthlinkhospital.dataaccess.AppointmentDAO;
import com.mycompany.healthlinkhospital.service.Appointment;
import com.mycompany.healthlinkhospital.service.Doctor;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.swing.JFrame;

import com.mycompany.healthlinkhospital.service.Patient;
import com.mycompany.healthlinkhospital.dataaccess.PatientDAO;
import com.mycompany.healthlinkhospital.dataaccess.UserDAO;
import com.mycompany.healthlinkhospital.service.User;


public class AddApointmentPage extends JFrame {
    private JComboBox<Patient> patientComboBox;
    private JComboBox<User> doctorComboBox;
    private JTextField appointmentDateField;
    private JButton addButton;
    private AppointmentDAO appointmentDAO;
    private PatientDAO patientDAO;
    private UserDAO userDAO;

    public AddApointmentPage() {
        setTitle("Add Appointment");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        appointmentDAO = new AppointmentDAO(); // Initialize AppointmentDAO (you should have this class implemented)
        patientDAO = new PatientDAO(); // Initialize PatientDAO
        userDAO = new UserDAO();

        JPanel panel = new JPanel(new GridLayout(4, 2));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JLabel patientLabel = new JLabel("Patient:");
        JLabel doctorLabel = new JLabel("Doctor:");
        JLabel appointmentDateLabel = new JLabel("Appointment Date (yyyy-MM-dd HH:mm):");

        List<Patient> patients = patientDAO.getAllPatients();
        List<User> doctors = userDAO.getAllUsersByRole("doctor");

        patientComboBox = new JComboBox<>(patients.toArray(new Patient[0]));
        doctorComboBox = new JComboBox<>(doctors.toArray(new User[0]));

        appointmentDateField = new JTextField();
        addButton = new JButton("Add Appointment");

        panel.add(patientLabel);
        panel.add(patientComboBox);
        panel.add(doctorLabel);
        panel.add(doctorComboBox);
        panel.add(appointmentDateLabel);
        panel.add(appointmentDateField);
        panel.add(new JLabel()); // Empty label for spacing
        panel.add(addButton);

        add(panel);

        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Get selected patient, doctor, and appointment date
                Patient selectedPatient = (Patient) patientComboBox.getSelectedItem();
                User selectedDoctor = (User) doctorComboBox.getSelectedItem();
                String appointmentDateStr = appointmentDateField.getText();

                try {
                    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                    Date appointmentDate = dateFormat.parse(appointmentDateStr);
                    String status = "Booked";

                    // Create a new Appointment object
                    Appointment newAppointment = new Appointment(selectedPatient.getPatientId(), selectedDoctor.getUserId(), appointmentDate,status);

                    // Call the AppointmentDAO to add the new appointment to the database
                    boolean success = appointmentDAO.addAppointment(newAppointment);

                    if (success) {
                        JOptionPane.showMessageDialog(null, "Appointment added successfully!");
                        // Close the form or perform necessary actions
                        dispose();
                    } else {
                        JOptionPane.showMessageDialog(null, "Failed to add appointment. Please try again.");
                    }
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(null, "Invalid date format. Please use yyyy-MM-dd HH:mm.");
                }
            }
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new AddApointmentPage().setVisible(true);
            }
        });
    }
}

