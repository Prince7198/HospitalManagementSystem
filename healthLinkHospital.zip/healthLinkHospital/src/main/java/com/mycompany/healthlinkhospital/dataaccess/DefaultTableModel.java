/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.healthlinkhospital.dataaccess;

import javax.swing.table.AbstractTableModel;
import java.util.ArrayList;
import java.util.List;

public class DefaultTableModel<T> extends AbstractTableModel {
    private List<T> data;
    private String[] columnNames;

    public DefaultTableModel(String[] columnNames) {
        this.columnNames = columnNames;
        this.data = new ArrayList<>();
    }

    public DefaultTableModel(String[] columnNames, List<T> data) {
        this.columnNames = columnNames;
        this.data = data;
    }

    public void setData(List<T> data) {
        this.data = data;
        fireTableDataChanged();
    }

    public List<T> getData() {
        return data;
    }

    @Override
    public int getRowCount() {
        return data.size();
    }

    @Override
    public int getColumnCount() {
        return columnNames.length;
    }

    @Override
    public String getColumnName(int columnIndex) {
        return columnNames[columnIndex];
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        if (rowIndex < 0 || rowIndex >= data.size() || columnIndex < 0 || columnIndex >= columnNames.length) {
            return null;
        }

        T rowData = data.get(rowIndex);
        // Implement logic to extract the appropriate data from your data model
        // For example, if T is a Patient object, you might extract values using methods like rowData.getFirstName(), rowData.getLastName(), etc.

        // Replace the following return statement with your actual data extraction logic
        return rowData;
    }

    // You can add more methods as needed to manipulate data in the table
}

