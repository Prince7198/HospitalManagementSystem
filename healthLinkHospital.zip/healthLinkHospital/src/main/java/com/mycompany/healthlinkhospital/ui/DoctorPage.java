/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.healthlinkhospital.ui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class DoctorPage extends JFrame {

    private JLabel loggedInLabel;

    public DoctorPage(String doctorName) {
        setTitle("Doctor Dashboard");
        setSize(400, 200);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel mainPanel = new JPanel(new GridLayout(3, 1));

        loggedInLabel = new JLabel("Logged in as: " + doctorName);
        loggedInLabel.setHorizontalAlignment(JLabel.CENTER);

        JButton viewAppointmentsButton = new JButton("View Appointments");
        JButton openEHRDashboardButton = new JButton("Open EHR Dashboard");

        mainPanel.add(loggedInLabel);
        mainPanel.add(viewAppointmentsButton);
        mainPanel.add(openEHRDashboardButton);

        viewAppointmentsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                viewAppointments();
            }
        });

        openEHRDashboardButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                openEHRDashboard();
            }
        });

        setContentPane(mainPanel);
    }

    private void viewAppointments() {
        // Open a page to view all appointments
        new ManageAppointmentsPage().setVisible(true);
    }

    private void openEHRDashboard() {
        // Open the Electronic Health Records (EHR) dashboard
        new EHRDashboard().setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                // Provide the doctor's name when creating the DoctorPage instance
                new DoctorPage("Dr. John Doe").setVisible(true);
            }
        });
    }
}
