/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.healthlinkhospital.ui;

/**
 *
 * @author Mtundi
 */
import com.mycompany.healthlinkhospital.dataaccess.PatientDAO;
import com.mycompany.healthlinkhospital.dataaccess.UserDAO;
import com.mycompany.healthlinkhospital.service.Patient;
import com.mycompany.healthlinkhospital.service.User;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class AddPatientPage extends JFrame {
    private JTextField firstNameField;
    private JTextField lastNameField;
    private JTextField dobField;
    private JTextField contactNumberField;
    private JTextField emailField;
    private JTextArea addressArea;
    private JButton addButton;
    private PatientDAO patientDAO;

    public AddPatientPage() {
        patientDAO = new PatientDAO();
        // Set up the JFrame
        setTitle("Add Patient");
        setSize(400, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        // Create a panel with a BorderLayout
        JPanel mainPanel = new JPanel(new BorderLayout());

        // Create a panel for the form
        JPanel formPanel = new JPanel(new GridLayout(7, 2, 10, 10));
        formPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // Add form components
        JLabel firstNameLabel = new JLabel("First Name:");
        firstNameField = new JTextField();
        JLabel lastNameLabel = new JLabel("Last Name:");
        lastNameField = new JTextField();
        JLabel dobLabel = new JLabel("Date of Birth (yyyy-MM-dd):");
        dobField = new JTextField();
        JLabel contactNumberLabel = new JLabel("Contact Number:");
        contactNumberField = new JTextField();
        JLabel emailLabel = new JLabel("Email:");
        emailField = new JTextField();
        JLabel addressLabel = new JLabel("Address:");
        addressArea = new JTextArea();

        formPanel.add(firstNameLabel);
        formPanel.add(firstNameField);
        formPanel.add(lastNameLabel);
        formPanel.add(lastNameField);
        formPanel.add(dobLabel);
        formPanel.add(dobField);
        formPanel.add(contactNumberLabel);
        formPanel.add(contactNumberField);
        formPanel.add(emailLabel);
        formPanel.add(emailField);
        formPanel.add(addressLabel);
        formPanel.add(new JScrollPane(addressArea));

        // Create a button to add the patient
        addButton = new JButton("Add Patient");

        // Add components to the main panel
        mainPanel.add(formPanel, BorderLayout.CENTER);
        mainPanel.add(addButton, BorderLayout.SOUTH);

        // Add the main panel to the JFrame
        add(mainPanel);

        // Add action listener for the Add Patient button
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Get patient information from the form fields
                String firstName = firstNameField.getText();
                String lastName = lastNameField.getText();
                String dob = dobField.getText();
                String contactNumber = contactNumberField.getText();
                String email = emailField.getText();
                String address = addressArea.getText();
                Date dateofbirth=null;
                
                
                SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

                try{
                     dateofbirth = dateFormat.parse(dob);
                    } catch(ParseException ex){
                      JOptionPane.showMessageDialog(null, "InCorrect Date or Incorrect Date Format!");

                        ex.printStackTrace();
                }

                // Validate and save the patient information to the database
                if (validateInput(firstName, lastName, dob, contactNumber, email, address)) {
                    Patient patient = new Patient(firstName,lastName,dateofbirth,contactNumber,email,address);
                    boolean success = patientDAO.createPatient(patient);

                    if (success) {
                        JOptionPane.showMessageDialog(null, "Patient added successfully!");
                        // Close the form or perform necessary actions
                        dispose();
                    } else {
                        JOptionPane.showMessageDialog(null, "Failed to add Patient. Please try again.");
                    }
                    dispose();
                } else {
                    JOptionPane.showMessageDialog(null, "Invalid input. Please check the fields.");
                }
            }
        });
    }

    // Add a validation method to validate input
    private boolean validateInput(String firstName, String lastName, String dob, String contactNumber, String email, String address) {
        // You can implement validation logic here
        // For example, check if fields are not empty and have valid formats
        return !firstName.isEmpty() && !lastName.isEmpty() && !dob.isEmpty() && !contactNumber.isEmpty() && !email.isEmpty() && !address.isEmpty();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new AddPatientPage().setVisible(true);
            }
        });
    }
}

