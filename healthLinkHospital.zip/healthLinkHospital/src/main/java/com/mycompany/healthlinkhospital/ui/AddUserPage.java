/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.healthlinkhospital.ui;

import com.mycompany.healthlinkhospital.dataaccess.UserDAO;
import com.mycompany.healthlinkhospital.service.User;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class AddUserPage extends JFrame {
    private JLabel adminLabel;
    private JLabel nameLabel;
        private JLabel passwordLabel;
    private JLabel roleLabel;

    private JTextField nameTextField;
        private JTextField passwordTextField;
        private JComboBox roleComboBox;

    private JButton registerButton;

    public AddUserPage(String adminName) {
        setTitle("Add User");
        setSize(400, 200);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); // Close this page without exiting the application
        setLocationRelativeTo(null);

        JPanel mainPanel = new JPanel(new GridLayout(3, 2));

        // Create labels and text fields
        adminLabel = new JLabel("Admin: " + adminName);
        nameLabel = new JLabel("User Name:");
        nameTextField = new JTextField();
                passwordLabel = new JLabel("User Password:");

        passwordTextField = new JTextField();
                roleLabel = new JLabel("User Role:");
                
                

                String[] roles = {"Doctor", "Receptionist", "Admin"};
        roleComboBox = new JComboBox<>(roles);


        // Create the Register button
        registerButton = new JButton("Register");

        // Add components to the main panel
        mainPanel.add(adminLabel);
        mainPanel.add(new JLabel()); // Placeholder
        mainPanel.add(nameLabel);
        mainPanel.add(nameTextField);
                mainPanel.add(passwordLabel);

        mainPanel.add(passwordTextField);
                mainPanel.add(roleLabel);
                mainPanel.add(roleComboBox);

        mainPanel.add(new JLabel()); // Placeholder
        mainPanel.add(registerButton);

        // Add an action listener to the Register button
        registerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String userName = nameTextField.getText();
                String passWord = passwordTextField.getText();
                String role = (String) roleComboBox.getSelectedItem();

                if (!userName.isEmpty()) {
                    // Create a new user object and add it to the database
                    User newUser = new User();
                    newUser.setUsername(userName);
                    newUser.setPassword(passWord);
                    newUser.setRole("User"); // You can set the default role here
                    UserDAO userDAO = new UserDAO();
                    if (userDAO.createUser(newUser)) {
                        JOptionPane.showMessageDialog(null, "User registered successfully.");
                        dispose(); // Close the Add User page
                    } else {
                        JOptionPane.showMessageDialog(null, "Failed to register the user.");
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Please enter a user name.");
                }
            }
        });

        setContentPane(mainPanel);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                // Example usage: pass the admin's name to the constructor
                new AddUserPage("AdminName").setVisible(true);
            }
        });
    }
}

