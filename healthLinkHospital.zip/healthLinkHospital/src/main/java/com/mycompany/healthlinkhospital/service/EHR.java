/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.healthlinkhospital.service;

/**
 *
 Electronic Health REcord
 */

public class EHR {
    private int ehrId;
    private int patientId;
    private String diagnosis;
    private String treatment;
    private String medicalHistory;
    private String allergies;

    // Getters and Setters for ehrId
    public int getEhrId() {
        return ehrId;
    }

    public void setEhrId(int ehrId) {
        this.ehrId = ehrId;
    }

    // Getters and Setters for patientId
    public int getPatientId() {
        return patientId;
    }

    public void setPatientId(int patientId) {
        this.patientId = patientId;
    }

    // Getters and Setters for diagnosis
    public String getDiagnosis() {
        return diagnosis;
    }

    public void setDiagnosis(String diagnosis) {
        this.diagnosis = diagnosis;
    }

    // Getters and Setters for treatment
    public String getTreatment() {
        return treatment;
    }

    public void setTreatment(String treatment) {
        this.treatment = treatment;
    }

    // Getters and Setters for medicalHistory
    public String getMedicalHistory() {
        return medicalHistory;
    }

    public void setMedicalHistory(String medicalHistory) {
        this.medicalHistory = medicalHistory;
    }

    // Getters and Setters for allergies
    public String getAllergies() {
        return allergies;
    }

    public void setAllergies(String allergies) {
        this.allergies = allergies;
    }
}

