/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.healthlinkhospital.ui;

import com.mycompany.healthlinkhospital.dataaccess.PatientDAO;
import com.mycompany.healthlinkhospital.dataaccess.PatientTableModel;
import com.mycompany.healthlinkhospital.service.Patient;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class PatientManagementPage extends JFrame {
    PatientDAO patientDAO;
    private JTable patientTable;
    private JButton addButton;
    private JButton editButton;
    private JButton deleteButton;

    public PatientManagementPage() {
        patientDAO = new PatientDAO();
       
        // Set up the JFrame
        setTitle("HealthLink Hospital - Patient Management");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        java.util.List<Patient> data =  patientDAO.getAllPatients();
        String[] columnNames = {"ID", "First Name", "Last Name", "Date of Birth", "Contact Number", "Email", "Address"};
        PatientTableModel model = new PatientTableModel(data, columnNames);
        JTable patientTable = new JTable(model);


        // Create a panel with a BorderLayout
        JPanel mainPanel = new JPanel(new BorderLayout());

        // Create a panel for buttons at the top
        JPanel buttonPanel = new JPanel();
        addButton = new JButton("Add Patient");
        editButton = new JButton("Edit Patient");
        deleteButton = new JButton("Delete Patient");

        buttonPanel.add(addButton);
        buttonPanel.add(editButton);
        buttonPanel.add(deleteButton);

        // Add the table to a scroll pane
        JScrollPane tableScrollPane = new JScrollPane(patientTable);

        // Add components to the main panel
        mainPanel.add(buttonPanel, BorderLayout.NORTH);
        mainPanel.add(tableScrollPane, BorderLayout.CENTER);

        // Add the main panel to the JFrame
        add(mainPanel);

        // Add action listeners for buttons
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
               new AddPatientPage().setVisible(true);

            }
        });

       editButton.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
        int selectedRow = patientTable.getSelectedRow();
        if (selectedRow != -1) {
            // Get the selected patient's ID
            int selectedPatientID = (int) patientTable.getValueAt(selectedRow, 0);
            
            // Open the EditPatientDialog and pass the selectedPatientID
            EditPatientPage editDialog = new EditPatientPage(selectedPatientID);
            editDialog.setVisible(true);
            
            // Refresh the patient table after editing
        }
    }
});

deleteButton.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
        int selectedRow = patientTable.getSelectedRow();
        if (selectedRow != -1) {
            int confirm = JOptionPane.showConfirmDialog(
                PatientManagementPage.this,
                "Are you sure you want to delete this patient?",
                "Confirm Deletion",
                JOptionPane.YES_NO_OPTION
            );
            
            if (confirm == JOptionPane.YES_OPTION) {
                // Get the selected patient's ID
                int selectedPatientID = (int) patientTable.getValueAt(selectedRow, 0);
                
                // Delete the patient from the database using your PatientDAO
                patientDAO.deletePatient(selectedPatientID);
                
                // Refresh the patient table after deletion
            }
        }
    }
});

      
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new PatientManagementPage().setVisible(true);
            }
        });
    }
}
