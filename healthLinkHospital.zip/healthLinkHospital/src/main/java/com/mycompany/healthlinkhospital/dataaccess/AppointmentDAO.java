/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.healthlinkhospital.dataaccess;

/**
 *
 * @author Mtundi
 */

import com.mycompany.healthlinkhospital.service.Appointment;

import com.mycompany.healthlinkhospital.service.Appointment;
import com.mycompany.healthlinkhospital.service.Doctor;
import com.mycompany.healthlinkhospital.service.Patient;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class AppointmentDAO {
    private Connection connection;

    public AppointmentDAO() {
        try {
                  connection = DatabaseConnector.getConnection();
              } catch (SQLException e) {
                  e.printStackTrace();
              }
          }

    // Add a new appointment to the database
    public boolean addAppointment(Appointment appointment) {
        String sql = "INSERT INTO appointments (patient_id, doctor_id, appointment_date, status) VALUES (?, ?, ?, ?)";

        try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setInt(1, appointment.getPatientId());
            preparedStatement.setInt(2, appointment.getDoctorId());
            preparedStatement.setTimestamp(3, new java.sql.Timestamp(appointment.getAppointmentDate().getTime()));
            preparedStatement.setString(4, appointment.getStatus());

            int rowsAffected = preparedStatement.executeUpdate();

            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Retrieve a list of all appointments from the database
    public List<Appointment> getAllAppointments() {
        List<Appointment> appointments = new ArrayList<>();
        String sql = "SELECT * FROM appointments";

        try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                Appointment appointment = mapResultSetToAppointment(resultSet);
                appointments.add(appointment);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return appointments;
    }

    // Retrieve an appointment by its ID from the database
    public Appointment getAppointmentById(int appointmentId) {
        String sql = "SELECT * FROM appointments WHERE appointment_id = ?";

        try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setInt(1, appointmentId);

            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                return mapResultSetToAppointment(resultSet);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return null;
    }

    // Update an existing appointment in the database
    public boolean updateAppointment(Appointment appointment) {
        String sql = "UPDATE appointments SET patient_id = ?, doctor_id = ?, appointment_date = ?, status = ? WHERE appointment_id = ?";

        try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setInt(1, appointment.getPatientId());
            preparedStatement.setInt(2, appointment.getDoctorId());
            preparedStatement.setTimestamp(3, new java.sql.Timestamp(appointment.getAppointmentDate().getTime()));
            preparedStatement.setString(4, appointment.getStatus());
            preparedStatement.setInt(5, appointment.getAppointmentId());

            int rowsAffected = preparedStatement.executeUpdate();

            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Delete an appointment by its ID from the database
    public boolean deleteAppointment(int appointmentId) {
        String sql = "DELETE FROM appointments WHERE appointment_id = ?";

        try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setInt(1, appointmentId);

            int rowsAffected = preparedStatement.executeUpdate();

            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Map a ResultSet row to an Appointment object
    private Appointment mapResultSetToAppointment(ResultSet resultSet) throws SQLException {
        int appointmentId = resultSet.getInt("appointment_id");
        int patientId = resultSet.getInt("patient_id");
        int doctorId = resultSet.getInt("doctor_id");
        java.util.Date appointmentDate = resultSet.getTimestamp("appointment_date");
        String status = resultSet.getString("status");

        // You should also fetch patient and doctor information from their respective tables
        // and create Patient and Doctor objects to set in the Appointment constructor
       // Patient patient = new Patient(); // Replace with actual patient retrieval
      //  Doctor doctor = new Doctor(); // Replace with actual doctor retrieval

        return new Appointment(appointmentId,patientId,doctorId,appointmentDate, status);
    }
}
